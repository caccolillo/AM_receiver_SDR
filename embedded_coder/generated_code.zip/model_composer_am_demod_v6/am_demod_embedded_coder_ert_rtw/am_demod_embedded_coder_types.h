/*
 * File: am_demod_embedded_coder_types.h
 *
 * Code generated for Simulink model 'am_demod_embedded_coder'.
 *
 * Model version                  : 1.247
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Wed Jan  1 15:47:44 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_am_demod_embedded_coder_types_h_
#define RTW_HEADER_am_demod_embedded_coder_types_h_

/* Model Code Variants */

/* Forward declaration for rtModel */
typedef struct tag_RTM_am_demod_embedded_cod_T RT_MODEL_am_demod_embedded_co_T;

#endif                         /* RTW_HEADER_am_demod_embedded_coder_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
